#include <iostream>
#include <vector>
#include <cmath>

// Pont struktúra létrehozása
struct Point {
    double x, y, z;
    Point(double x_, double y_, double z_) : x(x_), y(y_), z(z_) {}
};

// 3D pontok közötti távolság számítása
double distance(const Point& p1, const Point& p2) {
    double dx = p1.x - p2.x;
    double dy = p1.y - p2.y;
    double dz = p1.z - p2.z;
    return sqrt(dx * dx + dy * dy + dz * dz);
}

// Zárt görbe legrövidebb szakaszának hosszát kiszámító függvény
double shortestPathLength(const std::vector<Point>& curve) {
    if (curve.size() < 2)
        return 0.0;

    double minLength = distance(curve[0], curve[1]);

    for (size_t i = 1; i < curve.size(); ++i) {
        double segmentLength = distance(curve[i], curve[i + 1]);
        if (segmentLength < minLength)
            minLength = segmentLength;
    }

    return minLength;
}

// Egységtesztek
bool test_1() {
    std::vector<Point> curve = { Point(0, 0, 0), Point(1, 1, 1), Point(2, 2, 2), Point(3, 3, 3) };
    double result = shortestPathLength(curve);
    std::cout << std::endl;
    std::cout << std::endl;
    double sqrt3 = sqrt(3.0);
    // std::cout << sqrt3 << std::endl; //debug
    std::cout << "Test 1 result: " << result  << std::endl;
    return result == sqrt3;
}

bool test_2() {
    std::vector<Point> curve = { Point(0, 0, 0), Point(2, 2, 2), Point(0, 0, 1), Point(3, 3, 3), Point(2,0,-1) };
    double result = shortestPathLength(curve);
    //std::cout << sqrt(3.0) << std::endl; //debug
    std::cout << "Test 2 result: " << result << std::endl;
    return result == sqrt(9.0);
}

int main() {
    bool result1 = test_1();
    bool result2 = test_2();

    if (result1)
    {
        std::cout << "Teszt 1 sikeres!" << std::endl;
    }
    else
    {
        std::cout << "Teszt 1 sikertelen!" << std::endl;
    }
        
    if (result2)
    {
        std::cout << "Teszt 2 sikeres!" << std::endl;
    }
    else
    {
        std::cout << "Teszt 2 sikertelen!" << std::endl;
    }

    return 0;
}
