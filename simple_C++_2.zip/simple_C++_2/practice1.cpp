#include <iostream> 
#include <string>
#include <vector>
#include <limits>
#include <cstdlib>
#include <fstream>
#include <algorithm>

class Student{
    private:
        int id;
        std::string name;
        int age;
        float grade;
    
    public:
        Student() : id(0), name(""), age(0), grade(0.0f){}

        Student(int id_value, std::string name_value, int age_value, float grade_value)
            : id(id_value), name(name_value), age(age_value), grade(grade_value) {}

        int get_id() const { return id; }
        std::string get_name() const { return name; }
        int get_age() const { return age; }
        float get_grade() const { return grade; }

        void set_id(int new_id){ id = new_id; }
        void set_name(std::string new_name){ name = new_name; }
        void set_age(int new_age){ age = new_age; }
        void set_grade(float new_grade){ grade = new_grade; }

        void student_display() const{
            std::cout << "ID: " << id << ", Name: " << name << ", Age: " << age << ", Grade: " << grade << std::endl;
        }

        void input_student(){
            std::cout << "Enter ID: ";
            std::cin >> id;

            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

            std::cout << "Enter Name: ";
            std::getline(std::cin, name);

            std::cout << "Enter Age: ";
            std::cin >> age;

            std::cout << "Enter Grade: ";
            std::cin >> grade;
        }

};

void display_menu();
void add_student(std::vector<Student>& students);
void view_students(const std::vector<Student>& students);
void update_student(std::vector<Student>& students);
void delete_student(std::vector<Student>& students);
void save_students(const std::vector<Student>& students);
void load_students(std::vector<Student>& students);

int main(){
    std::vector<Student> students;
    load_students(students);

    int choice;
    do{
        display_menu();
        std::cin >> choice;
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); // clear input buffer

        switch (choice)
        {
        case 1:
            add_student(students);
            break;
        case 2:
            view_students(students);
            break;
        
        case 3:
            update_student(students);
            break;
        
        case 4:
            delete_student(students);
            break;
        
        case 5:
            save_students(students);
            break;
        
        case 6:
            std::cout << "Exiting program..." << std::endl;
            break;
        
        default:
            std::cout << "Invalid choice. Please try again." << std::endl;
            break;
        }

    }while(choice != 6);

    return 0;
}

int id_input(){
    int id;
    std::cout << "Enter an ID: ";
    std::cin >> id;
    return id;
}

void display_menu() {
    std::cout << "\nStudent Management System Menu:\n"
              << "1. Add Student\n"
              << "2. View Students\n"
              << "3. Update Student\n"
              << "4. Delete Student\n"
              << "5. Save Students\n"
              << "6. Exit\n"
              << "Enter your choice: ";
}
void add_student(std::vector<Student>& students){
    Student new_student;
    new_student.input_student();
    students.push_back(new_student);
    std::cout << "New student added. \n";
}

void view_students(const std::vector<Student>& students){
    std::cout << "\nStudents\n";
    for (const auto& s : students)
    {
        s.student_display();
    }    
}

void update_student(std::vector<Student>& students){
    int id = id_input();
    bool found = false;
    for (auto& s : students)
    {
        if (s.get_id() == id)
        {
            std::cout << "Enter new data for student \n";
            s.input_student();
            std::cout << "Student information updated.\n";
            found = true;
            break;
        }
    }
    if(!found){
        std::cout << "Student with ID " << id << " not found.\n";
    }
}

void delete_student(std::vector<Student>& students){
    int id = id_input();
    auto iterator = std::remove_if(students.begin(), students.end(), [id](const Student student){ return student.get_id(); });

    if (iterator != students.end())
    {
        students.erase(iterator);
        std::cout << "Student with " << id << "ID deleted" << "\n";
    }
    else
    {
        std::cout << "Student with " << id << "ID was not found" << "\n";
    }
    
    
}

void save_students(const std::vector<Student>& students){
    std::ofstream outFile("students.txt");
    if(!outFile){
        std::cerr << "Writable file not found!" << std::endl;
        return;
    }
    for (const auto& s : students)
    {
        outFile << s.get_id() << "," << s.get_name() << "," << s.get_age() << "," << s.get_grade() << "\n";
    }
    outFile.close();
    std::cout << "Student data saved to file!\n";
    
}

void load_students(std::vector<Student>& students){
    std::ifstream inFile("students.txt");
        if (!inFile) {
            std::cerr << "No existing data file found. Starting with an empty list.\n";
            return;
        }
        
    students.clear();

    int id, age;
    float grade;
    std::string name;

    char comma;

    while (inFile >> id >> comma >> std::ws && std::getline(inFile, name, ',') && inFile >> age >> comma >> grade) {
        students.emplace_back(id, name, age, grade);
    }

    inFile.close();
    std::cout << "Student data loaded from file.\n";
}