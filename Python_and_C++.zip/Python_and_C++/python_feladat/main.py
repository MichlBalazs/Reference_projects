import requests
from bs4 import BeautifulSoup
import os
import shutil
from PIL import Image
from io import BytesIO
import json
import subprocess
import platform

#BeautifulSoup setup
driver_url = "https://hu.wikipedia.org/wiki/Formula%E2%80%931"
response = requests.get(driver_url)
soup = BeautifulSoup(response.content, 'html.parser')
base_url = 'https://hu.wikipedia.org'


#RAJTSZÁMOK, PILÓTÁK ÉS CSAPATAIK KIGYŰJTÉSE (VAGY legutolsó csapatának kigyűjtése)
drivers = []

def get_drivers_team(driver_url):
#pilóta csapatának kikeresése
    drivers_team = None
    driver_response = requests.get(driver_url)
    driver_soup = BeautifulSoup(driver_response.content, 'html.parser')
    driver_info_table = driver_soup.find('table', {'class':'infobox ujinfobox'})
    driver_info_trs = driver_info_table.find_all('tr') # type: ignore
    relevant_tr = None
    for tr in driver_info_trs:
        tds = tr.find_all('td')
        for td in tds:
            if 'Csapata' in td.text:
                relevant_tr = tr
        if relevant_tr == None:
            for td in tds:
                if 'Korábbi csapatai' in td.text:
                    relevant_tr = tr


    if relevant_tr != None:
        driver_cols =  relevant_tr.find_all('td') # type: ignore
        cols_a_tags = driver_cols[1].find_all('a')
        drivers_team = cols_a_tags[-1].text
        
    return drivers_team

def create_drivers():
    #Táblázat megtalálása CSS osztály alapján
    drivers_table = soup.find('table', {'class': "wikitable sortable sticky-header"})
    #Fejlécen kívűli sorok megtalálása
    driver_rows = drivers_table.find_all('tr')[1:] # type: ignore
    driver_links = []
    for row in driver_rows:
        cols = row.find_all('td')
        if len(cols) == 4:
            driver_number = cols[0].text.strip()
            #pilóta csapatának kikeresése a pilóta wiki oldaláról
            driver_url = base_url + cols[2].find('a')['href']
            drivers_team = get_drivers_team(driver_url)
            driver_name = cols[2].text.strip()
            drivers.append({
                "driver_name":driver_name,
                "driver_number":driver_number,
                "driver_team":drivers_team
            })
        elif len(cols) == 3:
            driver_number = drivers[-1]['driver_number']
            driver_name = cols[1].text.strip()
            driver_url = base_url + cols[1].find('a')['href']
            drivers_team = get_drivers_team(driver_url)
            drivers.append({
                "driver_name":driver_name,
                "driver_number":driver_number,
                "driver_team":drivers_team
            })


#CSAPATOK MEGKERESÉSE
teams = []

def create_teams():
    #összes bekezdés megkeresése
    paragraphs = soup.find_all('p')
    relevant_paragraph = None

    #megfelelő bekezdés
    for paragraph in paragraphs:
        if 'A Formula–1-ben eddig több mint 300 különböző csapat vett részt' in paragraph.text:
            relevant_paragraph = paragraph
            break

    if relevant_paragraph:
        team_a_tags = relevant_paragraph.find_all('a')
        filtered_a_tags = []
        for a in team_a_tags:
            if '[' not in a.text:
                filtered_a_tags.append(a)
        teams = [a.get_text() for a in filtered_a_tags]



#MOTORSZÁLLÍTÓK MEGKERESÉSE

engine_suppliers=[]
cleaned_engine_suppliers = []

def create_cleaned_engine_suppliers():
    text = 'Formula–1-es világbajnok konstruktőrök listája'
    all_a_tags_in_soup = soup.find_all('a')
    for a in all_a_tags_in_soup:
        if text in a.text:
            relevant_a = a
            break

    half_motor_url = relevant_a.get('href')
    url_motor = base_url + half_motor_url
    response2 = requests.get(url_motor)
    soup_motor = BeautifulSoup(response2.content, 'html.parser')
    table_motor = soup_motor.find('table', {'class': "wikitable sortable sticky-header"})
    rows_motor = table_motor.find_all('tr')[1:-1] # type: ignore
    for row in rows_motor:
        cols = row.find_all('td')
        supplier = cols[3].text
        if supplier not in engine_suppliers:
            engine_suppliers.append(supplier)


    for s in engine_suppliers:
        cleaned_engine_suppliers.append(s.strip())
    

#ZÁSZLÓK ÉS JELENTÉSÜK MEGKERESÉSE
flags = []
def create_flags():
    #összes wiki table kiválasztása
    all_wiki_tables = soup.findAll('table', {'class':'wikitable'})
    relevant_table = None

    #megfelelő wikitable megkeresése header alapján
    for drivers_table in all_wiki_tables:
        header = drivers_table.find('th')
        if 'Zászló' in header.text:
            relevant_table = drivers_table
            break

    #zászlók és jelentésük megszerzése
    if relevant_table:
        driver_rows = relevant_table.find_all('tr')[1:]
        for row in driver_rows:
            cols = row.find_all('td')
            #hivatkozás kiegészítése
            flag_href = base_url + cols[0].find('a')['href']
            flag_meaning = cols[1].text
            flags.append({
                'flag_href':flag_href,
                'flag_meaning':flag_meaning
            })



#KÉPEK LETÖLTÉSE ÉS SZORTÍROZÁSA
#felbontás és kép méret meghatározásához pillow külső könyvtárat használtam

identified_dir = "identified"
not_identified_dir = "not_identified"
flags_dir = "flags"

if not os.path.exists(identified_dir):
    os.makedirs(identified_dir)
if not os.path.exists(not_identified_dir):
    os.makedirs(not_identified_dir)
if not os.path.exists(flags_dir):
    os.makedirs(flags_dir)


# képek tulajdonságainak meghatározása Pillow segítségével
images_with_properties = []
def create_image_properties(img_path):
    try:
        with Image.open(img_path) as img:
            resolution = f"{img.width}x{img.height}"
            image_extension = img.format.lower() # type: ignore
    except:
        resolution = 'n/a'
        image_extension = os.path.splitext(img_path)[1][1:].lower()
    
    image_size = os.path.getsize(img_path)

        
    return {
        "image": img_path,
        "resolution": resolution,
        "image_size": f"{image_size} bytes",
        "image_extension": image_extension
    }

def download_images():
    #összes kép megtalálása

    images = [img for img in soup.find_all('img') if not img.find_parent('noscript') and 'static' not in img['src']]
    
    search_list = []
    search_list.append('schumacher')
    for driver in drivers:
        separated_name = driver['driver_name'].split(' ')
        for name in separated_name:
            search_list.append(name.lower())
    for team in teams:
        search_list.append(team.lower())
    for supplier in cleaned_engine_suppliers:
        search_list.append(supplier.lower())

    for img in images:
        
        img_url = 'https:' + img['src']
        img_name = os.path.basename(img_url).lower()

        # Kép mentési helyének meghatározása
        folder = None
        if 'flag' in img_name:
            if 'f1' in img_name:
                folder = flags_dir
            else:
                folder = not_identified_dir
        else:
            identified = False
            for item in search_list:
                if item in img_name:
                    identified = True
            if identified:
                folder = identified_dir
            else:
                folder = not_identified_dir
                    
        
        if folder != None:  
            img_path = os.path.join(folder, img_name)
            # Kép letöltése és mentése
            img_data = requests.get(img_url).content
            with open(img_path, 'wb') as f:
                f.write(img_data)
            print(f"Saved {img_url} to {img_path}")
            images_with_properties.append(create_image_properties(img_path))


def write_json_data():
    #json file struktúra létrehozása
    json_data = {
        "drivers": drivers,
        "images": images_with_properties,
        "flag_rules": flags
        }
    #json file-ba kiírás
    with open('data.json', 'w', encoding='utf-8') as f:
        json.dump(json_data, f, ensure_ascii=False, indent=4)




create_drivers()
create_teams()
create_cleaned_engine_suppliers()
create_flags()
download_images()
write_json_data()

#stat txt tartalma:
number_of_drivers = len(drivers)
number_of_engine_suppliers = len(engine_suppliers)
number_of_images = len(images_with_properties)
number_of_identified_images = 0
number_of_not_identified_images = 0
size_of_all_images = 0
size_of_all_images_in_bytes = 0
average_size_of_images = 0
highest_resolution = 0
lowest_resolution = float('inf')


for img in images_with_properties:
    if 'not_identified' in img['image'].lower():
        number_of_not_identified_images += 1
    elif 'identified' in img['image'].lower():
        number_of_identified_images += 1

for img in images_with_properties:
    size_of_all_images_in_bytes += int(img['image_size'].split(' ')[0])
size_of_all_images = int(size_of_all_images_in_bytes) / 1024

average_size_of_images = size_of_all_images / len(images_with_properties)

for img in images_with_properties:
    resolution = img["resolution"]
    if resolution != 'n/a':  
        width, height = map(int, resolution.split("x"))
        resolution_size = int(width) * int(height)
        if resolution_size < lowest_resolution:
            lowest_resolution = resolution_size

max_res = 0
for img in images_with_properties:
    resolution = img["resolution"]
    if resolution != 'n/a':      
        width, height = map(int, resolution.split("x"))
        resolution_size = int(width) * int(height)
        if resolution_size > highest_resolution:
            highest_resolution = resolution_size




def generate_stat_file():
    os_platform = platform.system().lower()

    if os_platform == 'linux':
        script_name = './stat.sh'
    elif os_platform == 'windows':
        script_name = 'stat.bat'
    else:
        print("Nem támogatott operációs rendszer.")
        return

    params = [str(number_of_drivers), str(number_of_engine_suppliers),
              str(number_of_images), str(number_of_identified_images),
              str(number_of_not_identified_images), str(size_of_all_images),
              str(average_size_of_images), str(highest_resolution), str(lowest_resolution)]

    subprocess.run([script_name] + params, check=True)
    print()
    print("Statisztika elkészült.")

generate_stat_file()