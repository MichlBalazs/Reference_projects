#!/bin/bash

number_of_drivers=$1
number_of_engine_suppliers=$2
number_of_images=$3
number_of_identified_images=$4
number_of_not_identified_images=$5
size_of_all_images=$6
average_size_of_images=$7
highest_resolution=$8
lowest_resolution=$9

echo "number of drivers in the championship: $number_of_drivers" > stat.txt
echo "number of engine suppliers: $number_of_engine_suppliers" >> stat.txt
echo "number of images: $number_of_images" >> stat.txt
echo "number of identified images: $number_of_identified_images" >> stat.txt
echo "number of not identified images: $number_of_not_identified_images" >> stat.txt
echo "size of all images: $size_of_all_images" >> stat.txt
echo "average size of images: $average_size_of_images" >> stat.txt
echo "highest resolution: $highest_resolution" >> stat.txt
echo "lowest resolution: $lowest_resolution" >> stat.txt
